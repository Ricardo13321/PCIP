<?php
session_start();
//Responsável por organizar o filtro para armazenar os dados referentes as datas específicas
date_default_timezone_set('America/Sao_Paulo');

//Aqui é onde eu declaro as variáveis de sessão
$_SESSION['datas_aceitas'] = [];
$_SESSION['cargos'] = [];
$_SESSION["nomes"] = [];
$_SESSION["data_admissao"] = [];
$_SESSION['setor_funcionarios'] = [];
$_SESSION['codigo'] = [];
$_SESSION['quantidade'] = [];
$_SESSION['estado'] = [];
$_SESSION['date'] = [];
$_SESSION['hora'] = [];
$_SESSION["nome_entrega"] = [];
$_SESSION['id'] = [];
$_SESSION["retrabalho_couro"] = 0;
$_SESSION["retrabalho_cola"] = 0;
$_SESSION["producao_total"] = 0;
$_SESSION["produto_final"] = 0;
$_SESSION["perda"] = 0;
$_SESSION['data_inicial'] = date('Y-m-d');
$_SESSION['data_final'] = date('Y-m-d');
//$_SESSION['data_inicial_split'];
//$_SESSION['data_final_split'];
$_SESSION['privilegios'] = '';

//Pegando todos os dados dos arquivos json
$filecodigo = file_get_contents("../data/codigo.json");
$filequantidade = file_get_contents("../data/quantidade.json");
$fileestado = file_get_contents("../data/estado.json");
$filenomeentrega = file_get_contents("../data/nome_entrega.json");
$filedate = file_get_contents("../data/date.json");
$filehora = file_get_contents("../data/hora.json");
$filenomes = file_get_contents("../data/nome.json");
$filecargos = file_get_contents("../data/cargos.json");
$filesetorfuncionarios = file_get_contents("../data/setorfuncionarios.json");
$filedataadmissao = file_get_contents("../data/dataadmissao.json");

//Decodificando os dados e passando para um array da sessão respectivo
$decodedcargos = json_decode($filecargos, true);
$decodednomes = json_decode($filenomes, true);
$decodeddata_admissao = json_decode($filedataadmissao, true);
$decodedsetor_funcionarios = json_decode($filesetorfuncionarios, true);
$decodedcodigo = json_decode($filecodigo, true);
$decodedquantidade = json_decode($filequantidade, true);
$decodedestado = json_decode($fileestado, true);
$decodeddate = json_decode($filedate, true);
$decodedhora = json_decode($filehora, true);
$decodednome_entrega = json_decode($filenomeentrega, true);

$_SESSION['cargos'] =  $decodedcargos;
$_SESSION["nomes"] =  $decodednomes;
$_SESSION["data_admissao"] =  $decodeddata_admissao;
$_SESSION['setor_funcionarios'] =  $decodedsetor_funcionarios;

//Aqui é onde filtramos os dados
if (isset($_GET['data_inicial']) && isset($_GET['data_final'])) {
    $_SESSION['data_inicial'] = $_GET['data_inicial'];
    $_SESSION['data_final'] = $_GET['data_final'];
} else {
    $_SESSION['data_inicial'] = $decodeddate[0];
    $_SESSION['data_final'] = $decodeddate[(int)array_key_last($decodeddate)];
    $count = 0;
    $_loc_ = null;
    foreach ($decodeddate as $key => $value) {
        if ($value != $_loc_) {
            $_loc_ = $value;
            $count++;
        }
        if ($count == 7) {
            $_SESSION['data_final'] = $value;
            break;
        }
    }
}

$_SESSION['data_inicial_split'] = new DateTime($_SESSION['data_inicial']);
$_SESSION['data_final_split'] = new DateTime($_SESSION['data_final']);

foreach ($decodeddate as $key => $value) {
    $datesplit = new DateTime($value);
    //array_push($_SESSION['datas_aceitas'], $datesplit);
    if($datesplit >= $_SESSION['data_inicial_split'] && $datesplit <= $_SESSION['data_final_split']) {
        array_push($_SESSION['datas_aceitas'], $value);
        array_push($_SESSION['codigo'], $decodedcodigo[$key]);
        array_push($_SESSION['quantidade'], $decodedquantidade[$key]);
        array_push($_SESSION['estado'], $decodedestado[$key]);
        array_push($_SESSION['date'], $decodeddate[$key]);
        array_push($_SESSION['hora'], $decodedhora[$key]);
        array_push($_SESSION["nome_entrega"], $decodednome_entrega[$key]);
    }
}


//Essa função seta os privilégios do usuário o que limita o que ele pode editar no aplicativo.
if ($_SESSION['cargos'][$_SESSION['indice']] == 'chefe' || $_SESSION['cargos'][$_SESSION['indice']] == 'gerente de linha') {
    $_SESSION['privilegios'] = 'admin';
} elseif ($_SESSION['cargos'][$_SESSION['indice']] == 'funcionario') {
    $_SESSION['privilegios'] = 'funcionario';
} elseif ($_SESSION['cargos'][$_SESSION['indice']] == 'pcp') {
    $_SESSION['privilegios'] = 'pcp';
}

foreach ($_SESSION["estado"] as $key => $value) {
    if ($value == "Produto final") {
        $_SESSION["produto_final"] += $_SESSION["quantidade"][$key];
    } elseif ($value == "Defeito couro") {
        $_SESSION["retrabalho_couro"] += $_SESSION["quantidade"][$key];
    } elseif ($value == "Defeito cola") {
        $_SESSION["retrabalho_cola"] += $_SESSION["quantidade"][$key];
    } elseif ($value == "Perda") {
        $_SESSION["perda"] += $_SESSION["quantidade"][$key];
    }
    $_SESSION["producao_total"] += $_SESSION["quantidade"][$key];
}

//Esse trecho seta a session id para facilitar a manipulação de dados
for ($i=0; $i < count($_SESSION["nome_entrega"]); $i++) { 
    array_push($_SESSION['id'], $i);
}

if(isset($_GET['url'])) {
    header("Location: ".$_GET['url']);
} else {
    header("Location: ../areausuario.php");
}
?>