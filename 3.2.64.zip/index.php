<?php
    session_start();
    if (isset($_SESSION["usuario"])) {
        header("Location: areausuario.php");
        exit();
    } else {
        header("Location: view/login.php");
    }
?>