# PCIP
<h2>Painel de Controle de Produção (Simplificado)</h2>

<h3>Industria de sapatos</h3>

- Produção => 1000 pares de sapatos por partoda (modelo de sapatos). 
  -  E produz 1000 => semana de segunda à sábado, durante quatro semanas.
-20% de retrabalho => mas o permitido é 2%
  -Tipos de defeitos
    -cola
    -couro
- 18% de defeitos da produção mensal
- Números de homens/hora => 44 horas/8 homens
- Quem terá acesso ao admin?
  - chefe
  - pcp
  - 2 gerentes de linha

<hr>

- login
- dashboard admin
- listagem diaria dos funcionários/cadastro de refugo e tempo de produção
<img src="https://metricalist.com/wp-content/uploads/2023/04/Ecommerce%20Sales%20Dashboard.PNG">
