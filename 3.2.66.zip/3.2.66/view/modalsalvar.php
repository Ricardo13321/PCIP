<!-- Modal Filtrar Data-->
<div class="modal fade" id="modal_salvar" tabindex="-1" aria-labelledby="modal_salvar" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fs-5" id="atualizardata">SALVAR</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <divl class="modal-body">
                <iframe name="iframe_salvar" src="view/questionsalvar.html" style="width: 100%;"></iframe>
            </divl>
            <div class="modal-footer">
                <a href="controle/salvar.php" target="iframe_salvar"><input class="m-1 btn btn-success" type="button"  value="SALVAR"></a>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal" aria-label="Close">Cancelar</button>
            </div> 
        </div>
    </div>
</div>