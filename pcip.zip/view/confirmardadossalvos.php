<!-- Modal Dialogo -->
<div class="modal fade" id="modal_salvo" tabindex="-1" aria-labelledby="modal_salvo" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fs-5" id="atualizardata">DADOS SALVOS!</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <divl class="modal-body">
                <p>
                    Os dados foram salvos com sucesso!
                </p>
            </divl>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal" aria-label="Close">CONFIRMAR</button>
            </div> 
        </div>
    </div>
</div>